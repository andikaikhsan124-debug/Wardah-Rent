# Website Planning Document: Wardah Rent

## 1. Project Overview
* **Name:** Wardah Rent
* **Type:** Company Profile + Online Order (Photocopy & Print)
* **Goal:** Digitalize offline business for online promotion and orders.
* **Audience:** Students, youth, workers, housewives, general public.

## 2. Sitemap
* Home
* About Us
* Services (Photocopy B&W, Color Print, Scan, Binding & Laminating)
* Pricing
* Order / Upload File
* Gallery
* Testimonials
* Contact

## 3. Key Features
* File Upload (High Priority)
* WhatsApp Chat (0895393929392)
* Price List
* Service Descriptions
* Google Maps Integration
* Gallery of results
* Testimonials

## 4. Visual Direction
* **Colors:** Blue (#1E3A8A), Red (#DC2626), White (#FFFFFF), Light Gray (#F3F4F6)
* **Fonts:** Poppins (Titles), Roboto (Body)
* **Style:** Modern, minimalist, focus on CTA ("ORDER NOW", "SEND VIA WHATSAPP")

## 5. Homepage Structure
1. **Hero:** "Jasa Fotokopi & Print Cepat dan Murah"
2. **Featured Services:** Photocopy, Color Print, Scan, Binding
3. **Promos:** Student discounts, cheap color prints
4. **How to Order:** Upload/WA -> Process -> Pick up
5. **Gallery:** Photos of print results
6. **Testimonials:** Customer reviews
7. **Location:** Jalan Balai Rakyat No. 37, Matraman.
